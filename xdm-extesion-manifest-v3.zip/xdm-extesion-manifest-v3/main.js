import {xdm} from "./xdm.js";
import {util} from "./util.js";
import {requestWatcher} from "./requestWatcher.js"
import {messaging} from "./messaging.js";
import {monitoring} from "./monitoring.js"
//import {example} from "./example.js"
//import {example2} from "./example2.js"

xdm.util=util;
xdm.requestWatcher=requestWatcher;
xdm.messaging=messaging;
xdm.monitoring=monitoring;
xdm.extId=chrome.runtime.id;

//xdm.debug = true;
xdm.monitoring.run();


//xdm.example= example;
//xdm.example2= example2;
//xdm.example2();
/*
*///console.log("hello world");
