"use strict";
import {xdm} from "./xdm.js";
var messaging = {
    xhrHost: "http://127.0.0.1:9614",
    nativePort: undefined,
    nativeHostVerified: false,
    onDisconnect: function () {},
    onSync: function (data) {},
    connectWithApp: function (onSync, onDisconnect) {
		xdm.messaging.onDisconnect = onDisconnect;
        xdm.messaging.onSync = onSync;
        /*xdm.messaging.connectNative().then(function (port) {
            xdm.log("Connected successfully with native host");
            xdm.messaging.nativePort = port;
        }).catch(function () {
            xdm.log("Error with native messaging, trying with XHR");
            xdm.messaging.connectXHR();
        });*/
		
		xdm.messaging.connectXHR();
        chrome.runtime.onMessage.addListener(this.onPageMessage);
    },
    sendToXDM: function (request, response, file, video, referer) {
        xdm.log("sending to xdm: " + response.url + " " + xdm.messaging.nativePort);
        try {
            if (xdm.messaging.nativePort) {
                xdm.messaging.sendWithNativeMessaging(request, response, file, video, referer);
            } else {
                xdm.messaging.sendWithXHR(request, response, file, video, referer);
            }
        } catch (ex) { xdm.log(ex); }
    },
    sendUrlsToXDM: function (urls) {
        if (urls && urls.length > 0) {
            xdm.messaging.sendRecUrl(urls, 0, []);
        }
    },
    connectXHR: function () {
        setInterval(function () { xdm.messaging.pingXHR(); }, 5000);
    },
    connectNative: function () {
        return new Promise(function (resolve, reject) {
            xdm.messaging.nativePort = undefined;
            try {
                xdm.log("Connecting to native messaging host: xdm_chrome.native_host");
                var port = chrome.runtime.connectNative("xdm_chrome.native_host");
                xdm.log(port);
                if (!port) {
                    xdm.log("Unable to connect to native messaging host");
                    reject("Unable to connect to native messaging host");
                }
                xdm.log("Connected to native messaging host");
                port.onDisconnect.addListener(function () {
                    if (!xdm.messaging.nativePort) {
                        reject("Failed to connect to native messaging host!");
                    } else {
                        xdm.messaging.onDisconnect();
                        reject("Disconnected from native messaging host!");
                    }
                });
                port.onMessage.addListener(function (data) {
                    if (data.appExited) {
                        xdm.messaging.postNativeMessage({});
                        xdm.messaging.onDisconnect();
                    } else {
                        if (!xdm.messaging.nativePort) {
                            resolve(port);
                        }
                        xdm.messaging.onSync(data);
                    }
                });
            } catch (err) {
                log("Error while creating native messaging host");
                xdm.log(err);
                reject("Unable to connect to native messaging host");
            }
        });
    },
    pingXHR: function () {
    fetch(xdm.messaging.xhrHost + "/sync")
        .then(function(response) {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(function(data) {
			//console.log(data)
			
			//xdm.monitoring.testMonitoring("ssssss",data);
            xdm.messaging.onSync(data);
			
        })
        .catch(function(error) {
			xdm.log(error);
            xdm.messaging.onDisconnect("pingXHR");
        });
	},
	
	
    sendRecUrl: function (urls, index, data) {
    if (index > 0 && index == urls.length - 1) {
        xdm.log(data);
        if (xdm.messaging.nativePort) {
            xdm.log("Sending links to native host");
            xdm.messaging.postNativeMessage({ messageType: "links", messages: data });
        } else {
            var text = "";
            data.forEach(item => {
                text += "url=" + item.url + "\r\n";
                text += "res=realUA:" + navigator.userAgent + "\r\n";
                Object.keys(item.cookies).forEach(function (key) {
                    text += "cookie=" + key + ":" + item.cookies[key] + "\r\n";
                });
                text += "\r\n\r\n";
            });

            fetch(xdm.messaging.xhrHost + "/links", {
                method: 'POST',
                body: text
            })
                .then(function (response) {
                    // Manejar la respuesta si es necesario
                })
                .catch(function (error) {
                    // Manejar el error si es necesario
                });
        }
        return;
    }
    var url = urls[index];
    chrome.cookies.getAll({ "url": url }, function (cookies) {
			var cookieDict = {};
			cookies.forEach(cookie => {
				cookieDict[cookie.name] = cookie.value;
			});
			var linkItem = {
				url: url,
				cookies: cookieDict,
				responseHeaders: { realUA: [navigator.userAgent] }
			};
			data.push(linkItem);
			xdm.messaging.sendRecUrl(urls, index + 1, data);
		});
	},

   sendUrlToXDM: function (url) {
    xdm.log("sending to xdm: " + url);
    if (xdm.messaging.nativePort) {
        chrome.cookies.getAll({ "url": url }, function (cookies) {
            var cookieDict = {};
            cookies.forEach(cookie => {
                cookieDict[cookie.name] = cookie.value;
            });
            var data = {
                url: url,
                cookies: cookieDict,
                responseHeaders: { realUA: [navigator.userAgent] }
            };
            xdm.log(data);
            xdm.messaging.postNativeMessage({ messageType: "download", message: data });
        });
    } else {
        var data = "url=" + url + "\r\n";
        data += "res=realUA:" + navigator.userAgent + "\r\n";
        chrome.cookies.getAll({ "url": url }, function (cookies) {
            cookies.forEach(function (cookie) {
                data += "cookie=" + cookie.name + ":" + cookie.value + "\r\n";
            });
            xdm.log(data);
            fetch(xdm.messaging.xhrHost + "/download", {
                method: 'POST',
                body: data
            })
                .then(function (response) {
                    // Handle the response if necessary
                })
                .catch(function (error) {
                    // Handle the error if necessary
					});
			});
		}
	},

    sendWithNativeMessaging: function (request, response, file, video, referer) {
        var data = {
            url: response.url,
            file: file,
            requestHeaders: {},
            responseHeaders: {},
            cookies: {},
            method: request.method
        };
        var hasReferer = false;
        if (request.extraHeaders) {
            request.extraHeaders.forEach(header => {
                xdm.util.addToValueList(data.requestHeaders, header.name, header.value);
            });
        }
        if (request.requestHeaders) {
            request.requestHeaders.forEach(header => {
                if (header.name.toLowerCase() === 'referer') {
                    hasReferer = true;
                }
                xdm.util.addToValueList(data.requestHeaders, header.name, header.value);
            });
        }
        if (response.responseHeaders) {
            response.responseHeaders.forEach(header => {
                xdm.util.addToValueList(data.responseHeaders, header.name, header.value);
            });
        }
        xdm.util.addToValueList(data.responseHeaders, "tabId", request.tabId);
        xdm.util.addToValueList(data.responseHeaders, "realUA", navigator.userAgent);

        if (hasReferer === false && referer) {
            data += "req=Referer:" + referer + "\r\n";
        }
        xdm.messaging.postNativeMessage({ messageType: video ? "video" : "download", message: data });
    },
    sendWithXHR: function (request, response, file, video, referer) {
    xdm.log("Sending to xdm using xhr");
		console.log("referente recibido: "+referer);
    var data = "url=" + response.url + "\r\n";
    if (file) {
        data += "file=" + file + "\r\n";
    }
    var hasReferer = false;
    if (request.extraHeaders) {
        request.extraHeaders.forEach(function (header) {
            data += "req=" + header.name + ":" + header.value + "\r\n";
            xdm.log("extraHeaders: " + header.name + ":" + header.value);
        });
    }
    if (request.requestHeaders) {
        request.requestHeaders.forEach(function (header) {
            if (header.name == 'Referer') {
				
                hasReferer = true;
				data += "req=" + header.name + ":" + referer + "\r\n";
				xdm.log("requestHeaders: " + header.name + ":" + referer);
				
            }else{
				data += "req=" + header.name + ":" + header.value + "\r\n";
				xdm.log("requestHeaders: " + header.name + ":" + header.value);
			}
            
        });
    }
    if (response.responseHeaders) {
        response.responseHeaders.forEach(function (header) {
            data += "res=" + header.name + ":" + header.value + "\r\n";
            xdm.log("responseHeaders: " + header.name + ":" + header.value);
        });
    }
    if (hasReferer === false && referer) {
        data += "req=Referer:" + referer + "\r\n";
    }
    data += "res=tabId:" + request.tabId + "\r\n";
    data += "res=realUA:" + navigator.userAgent + "\r\n";
    chrome.cookies.getAll({ "url": response.url }, function (cookies) {
        if (cookies) {
            cookies.forEach(function (cookie) {
                data += "cookie=" + cookie.name + ":" + cookie.value + "\r\n";
            });
        }
        xdm.log(data);
        fetch(xdm.messaging.xhrHost + (video ? "/video" : "/download"), {
            method: 'POST',
            body: data
        })
            .then(function (response) {
                // Handle the response if necessary
            })
            .catch(function (error) {
                console.log(error)
            });
    });
},

    postNativeMessage: function (message) {
        if (xdm.messaging.nativePort) {
            try {
                xdm.messaging.nativePort.postMessage(message);
            } catch (err) {
                xdm.log(err);
                try { xdm.messaging.nativePort.disconnect(); } catch { }
                xdm.messaging.nativePort = undefined;
                xdm.messaging.onDisconnect();
            }
        }
    },
    onPageMessage: function (request, sender, sendResponse) {
		xdm.log("tipo: "+request.type);
    if (request.type === "links") {
        xdm.messaging.sendUrlsToXDM(request.links);
        sendResponse({ done: "done" });
    }  if (request.type === "stat") {
        var resp = {
            isDisabled: xdm.monitoring.state.disabled,
            list: xdm.monitoring.videoList,
            noEncoding: xdm.messaging.nativePort ? true : false
        };
        sendResponse(resp);
    }  if (request.type === "cmd") {
        xdm.monitoring.state.disabled = request.disable;
        xdm.log("disabled " + xdm.monitoring.state.disabled,request.disable);
    }  if (request.type === "vid") {
        if (xdm.monitoring.state.isXDMUp && xdm.messaging.nativePort) {
            xdm.messaging.postNativeMessage({ messageType: "videoIds", videoIds: [request.itemId + ""] });
        } else {
            fetch(xdm.messaging.xhrHost + "/item", {
                method: 'POST',
                body: request.itemId
            })
                .then(function (response) {
                    // Handle the response if necessary
                })
                .catch(function (error) {
                    // Handle the error if necessary
                });
        }
    } if (request.type === "clear") {
        if (xdm.messaging.nativePort) {
			//console.log("aaaaa")
            xdm.messaging.postNativeMessage({ messageType: "clear" });
        } else {
            fetch(xdm.messaging.xhrHost + "/clear", {
                method: 'GET'
            })
                .then(function (response) {
                    // Handle the response if necessary
                })
                .catch(function (error) {
                    // Handle the error if necessary
                });
        }
    }
	xdm.monitoring.updateBrowserAction();
},



};

export { messaging };