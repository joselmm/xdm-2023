"use strict";
import {xdm} from "./xdm.js";
var util = {
    parseUrl: function (str) {
        var match = str.match(/^(https?\:)\/\/(([^:\/?#]*)(?:\:([0-9]+))?)([\/]{0,1}[^?#]*)(\?[^#]*|)(#.*|)$/);
        return match && {
            href: str,
            protocol: match[1],
            host: match[2],
            hostname: match[3],
            port: match[4],
            pathname: match[5],
            search: match[6],
            hash: match[7]
        }
    },
    isBlocked: function (url) {
        var blockedHosts = xdm.monitoring.config.blockedHosts;
        for (var i = 0; i < blockedHosts.length; i++) {
            var hostName = this.parseUrl(url).hostname;
            if (hostName.indexOf(blockedHosts[i]) >= 0) {
                return true;
            }
        }
        return false;
    },
	
    isBlockedMime: function (mimeType) {
        var blockedMimeList = xdm.monitoring.config.blockedMimeList;
        for (var i = 0; i < blockedMimeList.length; i++) {
            if (mimeType && mimeType.indexOf(blockedMimeList[i]) >= 0) {
                return true;
            }
        }
        return false;
    },
    getFileExtension: function (file) {
        if (file) {
            var index = file.lastIndexOf(".");
            if (index > 0) {
                return file.substr(index + 1).trim();
            }
        }
    },
    hasMatchingExtension: function (file) {
        var ext = this.getFileExtension(file);
		xdm.log("extension extraida: "+ext)
        if (ext) {
			xdm.log("ext paso prueba")
            var fileExts = xdm.monitoring.config.fileExts;
            for (var i = 0; i < fileExts.length; i++) {
                if (fileExts[i] == ext.toUpperCase()) {
					xdm.log("si concide con xdm.monitoring.config.fileExts")
                    return true;
                }
            }
			var videoExts = xdm.monitoring.config.vidExts;
			for (var i = 0; i < videoExts.length; i++) {
                if (videoExts[i] == ext.toUpperCase()) {
					xdm.log("si concide xdm.monitoring.config.vidExts")
                    return true;
                }
            }
        }
		xdm.log("no concide")
        return false;
    },
    getFileFromContentDisposition: function (str) {
        var arr = str.split(";");
        for (var i = 0; i < arr.length; i++) {
            var ln = arr[i].trim();
            if (ln.indexOf("filename=") != -1) {
                var arr2 = ln.split("=");
                //var filename= arr2[1].replace(/"/g, '').trim();
				var filename= arr2[1].trim();
				if (filename.charAt(0) === '"' && filename.charAt(filename.length - 1) === '"') {
                filename = filename.slice(1, -1);
				}
				//xdm.log("nombre extraido: "+filename)
				return filename;
            }
        }
    },
    getAttachedFile: function (response) {
        for (var i = 0; i < response.responseHeaders.length; i++) {
            if (response.responseHeaders[i].name.toLowerCase() == 'content-disposition') {
                return this.getFileFromContentDisposition(response.responseHeaders[i].value);
            }
        }
    },
    getFileFromUrl: function (str) {
        return this.parseUrl(str).pathname;
    },
    hasMatchingUrlOrAttachment: function (response) {
        if (!response) {
            return false;
        }
        var file = this.getAttachedFile(response);
        if (file && this.hasMatchingExtension(file)) {
			console.log("si concide segun criterio 1")
            return true;
        }
        file = this.getFileFromUrl(response.url);
        if (file && this.hasMatchingExtension(file)) {
            return true;
        }
        return false;
    },
    guessFileName: function (response) {
        if (!response) {
            return;
        }
        var file = this.getAttachedFile(response);
        if (file) {
            return file;
        }
        file = this.getFileFromUrl(response.url);
        if (file) {
            return file;
        }
    },
    getResponseMime: function (response) {
        if (!response) return;
        for (var i = 0; i < response.responseHeaders.length; i++) {
            if (response.responseHeaders[i].name.toLowerCase() == "content-type") {
                return response.responseHeaders[i].value.toLocaleLowerCase();
            }
        }
    },
    isVideoMime: function (mimeText) {
        var mimeList = xdm.monitoring.config.mimeList;
        if (!mimeList) {
            return false;
        }
        var mime = mimeText.toLowerCase();
        for (var i = 0; i < mimeList.length; i++) {
            if (mime.indexOf(mimeList[i]) != -1) {
                return true;
            }
        }
        return false;
    },
    isKnownStreamingUrl: function (url) {
        var videoUrls = xdm.monitoring.config.videoUrls;
        if (!videoUrls) {
            return false;
        }
        for (var i = 0; i < videoUrls.length; i++) {
            var arr = videoUrls[i].split("|");
            var matched = true;
            for (var j = 0; j < arr.length; j++) {
                if (url.indexOf(arr[j]) < 0) {
                    matched = false;
                    break;
                }
            }
            if (matched) {
                return true;
            }
        }
    },
    hasVideoFileExtension: function (url) {
        var vidExts = xdm.monitoring.config.vidExts;
        if (!vidExts) return false;
        if (!url) return false;
        var file = this.getFileFromUrl(url);
        if (!file) return false;
        var ext = this.getFileExtension(file);
        if (!ext) return false;
        ext = ext.toUpperCase();
        for (var i = 0; i < vidExts.length; i++) {
            if (vidExts[i] == ext) {
                return true;
            }
        }
    },
    isStreamingVideo: function (response) {
        var mime = this.getResponseMime(response);
		//console.log("mime: "+mime);
        if (mime && (
			mime.startsWith("audio/") || 
			mime.startsWith("video/") ||
            mime.indexOf("mpegurl") > 0 || 
			mime.indexOf("f4m") > 0 ||
            this.isVideoMime(mime))
		   ) {
            return true;
        }
        if (response.url && (this.isKnownStreamingUrl(response.url) ||
            this.hasVideoFileExtension(response.url))) {
            return true;
        }
        return false;
    },
    addToValueList: function (dict, key, value) {
        var values = dict[key];
        if (values) {
            values.push(value);
        }
        dict[key] = [value];
    },
    arrayBufferToBase64: function (buffer) {
        var binary = '';
        var bytes = new Uint8Array(buffer);
        var len = bytes.byteLength;
        for (var i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return window.btoa(binary);
    },
	isYouTubeUrl: function (url) {
		return url.includes('youtube.com') && (url.includes('/watch') || url.includes('/embed'));
	},
	getYoutubeVideoFormats: function(videoId) {
		console.log("hy");
		return new Promise(async (resolve, reject)=>{
			var encodedUri = encodeURIComponent('https://www.youtube.com/watch?v=' + videoId);
			var error = false;
			var resp = [];
		
			try {
				 var response = await fetch("https://www.y2mate.com/mates/analyzeV2/ajax", {
					"headers": {
						"accept": "*/*",
						"accept-language": "es-CO,es-HN;q=0.9,es;q=0.8,en-US;q=0.7,en-GB;q=0.6,en;q=0.5,es-ES;q=0.4",
						"content-type": "application/x-www-form-urlencoded; charset=UTF-8",
						"sec-ch-ua": "\"Chromium\";v=\"118\", \"Google Chrome\";v=\"118\", \"Not=A?Brand\";v=\"99\"",
						"sec-ch-ua-mobile": "?0",
						"sec-ch-ua-platform": "\"Linux\"",
						"sec-fetch-dest": "empty",
						"sec-fetch-mode": "cors",
						"sec-fetch-site": "same-origin",
						"x-requested-with": "XMLHttpRequest"
					},
					"referrer": "https://www.y2mate.com/youtube/" + videoId,
					"referrerPolicy": "strict-origin-when-cross-origin",
					"body": "k_query=" + encodedUri + "&k_page=home&hl=en&q_auto=1",
					"method": "POST",
					"mode": "cors",
					"credentials": "omit"
				});

				var result = await response.json();
				console.log("result:");
				console.log(result);

				if (result.status !== "ok") {
					error = true;
				}
				console.log("se ejecutara")
				if (result.hasOwnProperty("links") && result.links.hasOwnProperty("mp4")) {
					var mp4LinksObj = result.links.mp4;
					for (var name in mp4LinksObj) {
						if (mp4LinksObj.hasOwnProperty(name)) {
							resp.push(mp4LinksObj[name]);
						}
					}
				}
				if (resp.length===0) {
					error = true;
				}
			} catch (e) {
				error = true;
				xdm.log("util.getYoutubeVideoFormats: hubo un error al intentar obtener los formatos de video de YouTube para " + videoId + ":" + e.message);
			}

			if (error) {
				resolve(null);
			}

				resolve(resp);

		});
	},
	extractYouTubeVideoId: function (url) {
		var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#&?]*).*/;
		var match = url.match(regExp);
		return (match && match[7].length === 11) ? match[7] : null;
	},
	requestExample:function(dlink){
		return ({
			"documentLifecycle": "active",
			"frameId": 0,
			"frameType": "outermost_frame",
			"initiator": "https://www.y2mate.com",
			"method": "GET",
			"parentFrameId": -1,
			"requestHeaders": [
				{
					"name": "sec-ch-ua",
					"value": "\"Chromium\";v=\"118\", \"Google Chrome\";v=\"118\", \"Not=A?Brand\";v=\"99\""
				},
				{
					"name": "sec-ch-ua-mobile",
					"value": "?0"
				},
				{
					"name": "sec-ch-ua-platform",
					"value": "\"Linux\""
				},
				{
					"name": "Upgrade-Insecure-Requests",
					"value": "1"
				},
				{
					"name": "User-Agent",
					"value": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36"
				},
				{
					"name": "Accept",
					"value": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
				},
				{
					"name": "Sec-Fetch-Site",
					"value": "cross-site"
				},
				{
					"name": "Sec-Fetch-Mode",
					"value": "navigate"
				},
				{
					"name": "Sec-Fetch-User",
					"value": "?1"
				},
				{
					"name": "Sec-Fetch-Dest",
					"value": "document"
				},
				{
					"name": "Referer",
					"value": "https://www.y2mate.com/"
				},
				{
					"name": "Accept-Encoding",
					"value": "gzip, deflate, br"
				},
				{
					"name": "Accept-Language",
					"value": "es-CO,es-HN;q=0.9,es;q=0.8,en-US;q=0.7,en-GB;q=0.6,en;q=0.5,es-ES;q=0.4"
				}
			],
			"requestId": (""+Math.random()).slice(-4),
			"tabId": -1,
			"timeStamp": Date.now(),
			"type": "main_frame",
			"url": dlink
		});
	
	},
	
	responseExample:function(size, quality, ext){
		
		return ({
			"documentLifecycle": "active",
			"frameId": 0,
			"frameType": "outermost_frame",
			"initiator": "https://www.y2mate.com",
			"method": "GET",
			"parentFrameId": -1,
			"requestId": "1065",
			"responseHeaders": [
				{
					"name": "date",
					"value": xdm.util.generateUSAStringDate()
				},
				{
					"name": "content-type",
					"value": xdm.util.getMIMEType(ext.toLowerCase())
				},
				{
					"name": "quality",
					"value": quality
				},
				{
					"name": "content-length",
					"value": convertStringMBtoContentLength(size)
				},
				{
					"name": "x-powered-by",
					"value": "PHP/5.4.16"
				},
				{
					"name": "cache-control",
					"value": "public, must-revalidate, post-check=0, pre-check=0"
				},
				{
					"name": "expires",
					"value": "Thu, 19 Oct 2023 12:32:58 GMT"
				},
				{
					"name": "content-disposition",
					"value": "attachment; filename=\"y2mate.com%20-%20Shakira%20Fuerza%20Regida%20%20El%20Jefe%20Official%20Video_720p.mp4\"; filename*=utf-8''y2mate.com%20-%20Shakira%20Fuerza%20Regida%20%20El%20Jefe%20Official%20Video_720p.mp4"
				},
				{
					"name": "accept-ranges",
					"value": "bytes"
				},
				{
					"name": "cf-cache-status",
					"value": "DYNAMIC"
				},
				{
					"name": "report-to",
					"value": "{\"endpoints\":[{\"url\":\"https:\\/\\/a.nel.cloudflare.com\\/report\\/v3?s=eyWthAozXljXtbeF%2FlUoENE1nu8ED7Ro%2BnupWnAOo5lvfzGqXkd%2FpfT3oBkK92PEzuczgp1%2FYqNAn%2FaGBvk4kgY5%2B9pfzDyBOuofadD6sPNmtem5KqlThbMRr8cnBG%2BlLfB7oOPX0fc%3D\"}],\"group\":\"cf-nel\",\"max_age\":604800}"
				},
				{
					"name": "nel",
					"value": "{\"success_fraction\":0,\"report_to\":\"cf-nel\",\"max_age\":604800}"
				},
				{
					"name": "server",
					"value": "cloudflare"
				},
				{
					"name": "cf-ray",
					"value": "8188b4160d9db3b6-MIA"
				},
				{
					"name": "alt-svc",
					"value": "h3=\":443\"; ma=86400"
				}
			],
			"statusCode": 200,
			"statusLine": "HTTP/1.1 200",
			"tabId": -1,
			"timeStamp": Date.now(),
			"type": "main_frame",
			"url": dlink
		})
	},
	generateUSAStringDate(){
		var currentDate = new Date();
		var utcString = currentDate.toUTCString();
		var formattedString = utcString.replace(/,(\d{2}),/, ' $1').replace(/-[\d]+$/, '');
		return formattedString;
	},
	getMIMEType:function (extension) {
		var mimeTypes = {
			'mp3': 'audio/mpeg',
			'wav': 'audio/wav',
			'ogg': 'audio/ogg',
			'mp4': 'video/mp4',
			'webm': 'video/webm',
			'ogg': 'video/ogg',
			'3gp': 'video/3gpp'
			// Puedes agregar más extensiones y tipos MIME según sea necesario
		};

		return mimeTypes[extension] || 'application/octet-stream';
	},
	convertStringMBtoContentLength:function (mbString) {
    // Extraer el valor numérico de la cadena
    var mb = parseFloat(mbString);
    if (isNaN(mb)) {
        return null; // Retornar null si no se puede convertir en un número válido
    }

    // Convertir de megabytes a bytes
    var bytes = mb * 1024 * 1024;
    return bytes;
	},
	getDirectVideoLinks: function (formats, videoId){
		
		return new Promise(async (resolve,reject)=>{
			
			var directLinks = [];
			var encodedVId = encodeURIComponent(videoId);
			console.log(formats)
			console.log(videoId)
			for(let i=0; i<1; i++){
				var format =formats[i];
				console.log(format)
				var encodedK= encodeURIComponent(format.k);
				console.log(encodedK)
				var result =null;
					
				try{
					
					
					var response = await fetch("https://www.y2mate.com/mates/convertV2/index", {
					  "headers": {
						"accept": "*/*",
						"accept-language": "es-CO,es-HN;q=0.9,es;q=0.8,en-US;q=0.7,en-GB;q=0.6,en;q=0.5,es-ES;q=0.4",
						"content-type": "application/x-www-form-urlencoded; charset=UTF-8",
						"sec-ch-ua": "\"Chromium\";v=\"118\", \"Google Chrome\";v=\"118\", \"Not=A?Brand\";v=\"99\"",
						"sec-ch-ua-mobile": "?0",
						"sec-ch-ua-platform": "\"Linux\"",
						"sec-fetch-dest": "empty",
						"sec-fetch-mode": "cors",
						"sec-fetch-site": "same-origin",
						"x-requested-with": "XMLHttpRequest"
					  },
					  "referrer": "https://www.y2mate.com/",
					  "referrerPolicy": "strict-origin-when-cross-origin",
					  "body": "vid="+videoId+"&k="+encodedK,
					  "method": "POST",
					  "mode": "cors",
					  "credentials": "omit"
					});

					result = await response.json();
					console.log(result)
					if(result.c_status!="CONVERTED")return;
						directLinks.push(
							{
								dlink:result.dlink,
								size:format.size,
								title:result.title,
								ext:result.ftype,
								quality:format.q

							})
					
				}catch(e){
					console.log(e);
				}

			}
			resolve(directLinks);
		});
	},
	
	sendYoutubeIdToXDM:function (args){
		fetch(xdm.messaging.xhrHost + "/yt-video-id", {
                method: 'POST',
				headers:{
					"Content-Type":"application/json"
				},
				body:JSON.stringify(args)
            })
                .then(res=>res.json())
				.then(object=>{
					//xdm.monitoring.onSync(data);
					//console.log(object)
				})
                .catch(function (error) {
                    console.log("error con yt-video-id: "+error.message);
                });
	}
	
};

export {util};