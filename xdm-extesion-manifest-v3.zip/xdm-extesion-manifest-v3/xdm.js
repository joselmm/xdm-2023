var xdm = {
	debug:false,
	log:function (content){
		if(this.debug===true){
			console.log(content);
		}
	}

}

export {xdm};